
#
# iter = range(3).__iter__()
# print(iter)
# print(iter.__next__())
# print(iter.__next__())
# print(iter.__next__())
# print(iter.__next__())


class CustomRange:
    def __init__(self, start, end):
        self.current = start
        self.end = end

    def __iter__(self):
        return self

    def __next__(self):
        if self.current < self.end:
            rvalue = self.current
            self.current += 1
            return rvalue
        else:
            raise StopIteration

for i in CustomRange(1,5):
    print(i)

for i in [10,20,30]:
    print(i)

print()
ddata = {'name':'kim', 'age':30}
for k in ddata.keys():
    print(k)







