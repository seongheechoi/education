a = 100
a = int(100)
print(type(a))

data = [333, True, 634.41, 'abcd', [4,44,77]]
print(data)
data2 = [[1,2,3,4], [5,6,7,8]]
data3 = [[1,2,3,4], [22,33], [6,7,8,9,10,12,15]]
print(data3)
print(data3[0])
print(data3[1])
print(data3[2])


