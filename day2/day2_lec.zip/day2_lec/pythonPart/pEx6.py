str1 =  '    python    '
print('*',str1,'*')
print('*',str1.strip(),'*')
print('*',str1.lstrip(),'*')
print('*',str1.rstrip(),'*')

str2 = ',python,.'
print(str2.strip(',.'))
