ddata1 = {'name':'kim', 'age':30, 'address':'seoul'}

print(ddata1.keys())

for k in ddata1.keys():
    print(k)

print()
for k,v in ddata1.items():
    print(k, v)


ddata1 = {'name':'kim', 'age':30, 'address':'seoul'}

def print_info(name, age, address):
    print(f'name:{name}, age:{age}, address:{address}')

print()
print_info(name=ddata1['name'], age=ddata1['age'], address=ddata1['address'])
print_info(**ddata1)

print()
def print_info2(**data):
    for k, v in data.items():
        print(k,v, sep=':')

print_info2(name='kim', age=30, address='busan', weight=90)


