infile1 = open('USPres.txt', 'r')
infile2 = open('VPres.txt', 'r')

sdata1 = {line for line in infile1}
sdata2 = {line for line in infile2}

infile1.close()
infile2.close()

idata = sdata1.intersection(sdata2)
print(idata)

outfile1 = open('bdata.txt', 'w')
outfile1.writelines(idata)
outfile1.close()

ldata = sorted(idata)
print(ldata)

outfile2 = open('bdata2.txt', 'w')
outfile2.writelines(ldata)
outfile2.close()
