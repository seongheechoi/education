def insa():
    print('안녕하세요')

fvalue = insa
print(fvalue)
fvalue()


def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

flist = [add, subtract]
print(flist[1](10, 20))

def calc(cf, a, b):
    rvalue = cf(a, b)
    print('result: ',rvalue)

calc(add, 30,70)

