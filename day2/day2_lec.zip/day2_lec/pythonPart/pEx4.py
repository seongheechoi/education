for i in range(0,5,1):
    print(i)

a = range(0,5,1)
print(type(a))

ldata1 = [10, 40, 50, 70]
print()
for data in ldata1:
    print(data)
