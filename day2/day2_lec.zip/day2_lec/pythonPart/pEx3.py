score = int(input('input_score:'))

if score > 90:
    print('grade A')
elif score > 80:
    print('grade B')
elif score > 70:
    print('grade C')
else:
    print('....')
