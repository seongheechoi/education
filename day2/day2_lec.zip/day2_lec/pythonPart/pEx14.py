'''
class Person:
    def __init__(self, name, age, address):
        self.name = name
        self.age = age
        self.address = address

    def print_info(self):
        print(f'name:{self.name}, age:{self.age}, address:{self.address}')


smith = Person('smith', 30, 'utah')
smith.print_info()
'''
class InstanceC:
    #text_list = []
    def __init__(self):
        self.text_list = []
    def add(self, text):
        self.text_list.append(text)

    def print_list(self):
        print(self.text_list)


obj1 = InstanceC()
obj1.add('first')
obj1.print_list()

obj2 = InstanceC()
obj2.add('second')
obj2.print_list()












