ivalue = 1032423223
fvalue = 5324523323.32523

str1 = '정수값 :%d, 실수값:%f'%(ivalue, fvalue)
print(str1)

str2 = '정수값 :{0}, 실수값:{1}'.format(ivalue, fvalue)
print(str2)

str3 = '정수값 :{:<10}, 실수값:{:<10.2f}'.format(ivalue, fvalue)
print(str3)

print('{:,.3f}'.format(fvalue))

str4 = f'정수값 :{ivalue}, 실수값:{fvalue}'
print(str4)

str5 = f'정수값 :{ivalue:,}, 실수값:{fvalue:,.3f}'
print(str5)
