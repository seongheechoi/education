str1 = 'it is a good day'
data = str1.split()
print(data)
print(str1.split(' ', 1))
print(str1.split(' ', 2))
print(str1.split(' ', 3))
