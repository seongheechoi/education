ldata1 = [10, 20, 30]
ldata2 = [100,200]
ldata3 = ldata1 + ldata2;
print(ldata3)
