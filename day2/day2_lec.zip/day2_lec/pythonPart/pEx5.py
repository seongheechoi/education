str1 = 'abcde'
print(str1[2])
print(str1[1:3])

for c in 'Hello':
    print(c)


str2 = 'hi '
str3 = 'hello'
print(str2 + str3)
print(str3 * 2)
