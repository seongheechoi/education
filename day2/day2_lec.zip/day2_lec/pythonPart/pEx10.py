sdata1 = {3,2,4,1,2,4,1,2,3}
print(sdata1)

sdata2 = {1,2,3,4}
sdata3 = {3,4,5,6}


print(set.union(sdata2, sdata3))
print(sdata2.union(sdata3))
print(sdata2 | sdata3)

print()

print(sdata2.intersection(sdata3))
print(sdata2 & sdata3)
print(sdata2.difference(sdata3))
print(sdata2 - sdata3)
print(sdata2.symmetric_difference(sdata3))
print(sdata2 ^ sdata3)

ldata = [10,20,30,10,20,30]
sdata4 = set(ldata)
print(sdata4)

sdata5 = {}
print(type(sdata5))
sdata6 = set()
print(type(sdata6))
